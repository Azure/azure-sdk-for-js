// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export {};
//# sourceMappingURL=interactiveCredentialOptions.js.map