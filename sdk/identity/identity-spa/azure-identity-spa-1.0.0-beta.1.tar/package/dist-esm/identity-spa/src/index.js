// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export { RedirectCredential } from "./redirectCredential";
export { PopupCredential } from "./popupCredential";
//# sourceMappingURL=index.js.map