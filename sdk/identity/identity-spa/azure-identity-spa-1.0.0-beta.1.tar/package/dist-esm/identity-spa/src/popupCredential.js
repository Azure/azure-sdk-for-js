// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { __awaiter } from "tslib";
import { credentialLogger, formatError } from "../../identity/src/util/logging";
const BrowserNotSupportedError = new Error("PopupCredential is not supported in Node.js");
const logger = credentialLogger("PopupCredential");
/**
 * (Only available in browsers)
 * Enables authentication to Azure Active Directory inside of the web browser
 * using the interactive login flow within a browser popup window.
 */
export class PopupCredential {
    /**
     * (Only available in browsers)
     * Creates an instance of the PopupCredential with the
     * details needed to authenticate against Azure Active Directory with
     * a user identity.
     *
     * This credential uses the [Authorization Code Flow](https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-auth-code-flow).
     * On Node.js, it will open a browser window while it listens for a redirect response from the authentication service.
     * On browsers, it authenticates via popups. The `loginStyle` optional parameter can be set to `redirect` to authenticate by redirecting the user to an Azure secure login page, which then will redirect the user back to the web application where the authentication started.
     *
     * Configure your AAD Application to authenticate using a Single Page Application redirect endpoint.
     * More information here: [link](https://docs.microsoft.com/en-us/azure/active-directory/develop/scenario-spa-app-registration#redirect-uri-msaljs-20-with-auth-code-flow).
     *
     * @param options - Options for configuring the client which makes the authentication request.
     */
    constructor(_options) {
        logger.info(formatError("", BrowserNotSupportedError));
        throw BrowserNotSupportedError;
    }
    /**
     * (Only available in browsers)
     * Authenticates with Azure Active Directory and returns an access token if successful.
     * If authentication fails, a {@link CredentialUnavailableError} will be thrown with the details of the failure.
     *
     * @param scopes - The list of scopes for which the token will have access.
     * @param options - The options used to configure any requests this
     *                TokenCredential implementation might make.
     */
    getToken() {
        logger.getToken.info(formatError("", BrowserNotSupportedError));
        throw BrowserNotSupportedError;
    }
    /**
     * (Only available in browsers)
     * Authenticates with Azure Active Directory and returns an access token if successful.
     * If authentication fails, a {@link CredentialUnavailableError} will be thrown with the details of the failure.
     *
     * If the token can't be retrieved silently, this method will require user interaction to retrieve the token.
     *
     * @param scopes - The list of scopes for which the token will have access.
     * @param options - The options used to configure any requests this
     *                  TokenCredential implementation might make.
     */
    authenticate() {
        return __awaiter(this, void 0, void 0, function* () {
            logger.getToken.info(formatError("", BrowserNotSupportedError));
            throw BrowserNotSupportedError;
        });
    }
    /**
     * Tries to authenticate and retrieves parameters from the URL hash
     */
    onPageLoad() {
        return __awaiter(this, void 0, void 0, function* () {
            logger.getToken.info(formatError("", BrowserNotSupportedError));
            throw BrowserNotSupportedError;
        });
    }
}
//# sourceMappingURL=popupCredential.js.map