import { AccessToken } from '@azure/core-auth';
import { AuthenticationRecord } from '@azure/identity';
import { CredentialPersistenceOptions } from '@azure/identity';
import { InteractiveCredentialOptions } from '@azure/identity';
import { TokenCredential } from '@azure/core-auth';

/**
 * (Only available in browsers)
 * Enables authentication to Azure Active Directory inside of the web browser
 * using the interactive login flow within a browser popup window.
 */
export declare class PopupCredential implements TokenCredential {
    /**
     * (Only available in browsers)
     * Creates an instance of the PopupCredential with the
     * details needed to authenticate against Azure Active Directory with
     * a user identity.
     *
     * This credential uses the [Authorization Code Flow](https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-auth-code-flow).
     * On Node.js, it will open a browser window while it listens for a redirect response from the authentication service.
     * On browsers, it authenticates via popups. The `loginStyle` optional parameter can be set to `redirect` to authenticate by redirecting the user to an Azure secure login page, which then will redirect the user back to the web application where the authentication started.
     *
     * Configure your AAD Application to authenticate using a Single Page Application redirect endpoint.
     * More information here: [link](https://docs.microsoft.com/en-us/azure/active-directory/develop/scenario-spa-app-registration#redirect-uri-msaljs-20-with-auth-code-flow).
     *
     * @param options - Options for configuring the client which makes the authentication request.
     */
    constructor(_options: SPACredentialOptions);
    /**
     * (Only available in browsers)
     * Authenticates with Azure Active Directory and returns an access token if successful.
     * If authentication fails, a {@link CredentialUnavailableError} will be thrown with the details of the failure.
     *
     * @param scopes - The list of scopes for which the token will have access.
     * @param options - The options used to configure any requests this
     *                TokenCredential implementation might make.
     */
    getToken(): Promise<AccessToken | null>;
    /**
     * (Only available in browsers)
     * Authenticates with Azure Active Directory and returns an access token if successful.
     * If authentication fails, a {@link CredentialUnavailableError} will be thrown with the details of the failure.
     *
     * If the token can't be retrieved silently, this method will require user interaction to retrieve the token.
     *
     * @param scopes - The list of scopes for which the token will have access.
     * @param options - The options used to configure any requests this
     *                  TokenCredential implementation might make.
     */
    authenticate(): Promise<AuthenticationRecord | undefined>;
    /**
     * Tries to authenticate and retrieves parameters from the URL hash
     */
    onPageLoad(): Promise<{
        code?: string;
        state?: string;
    }>;
}

/**
 * (Only available in browsers)
 * Enables authentication to Azure Active Directory inside of the web browser
 * using the interactive login flow through redirecting within the same browser window.
 */
export declare class RedirectCredential implements TokenCredential {
    /**
     * (Only available in browsers)
     * Creates an instance of the RedirectCredential with the
     * details needed to authenticate against Azure Active Directory with
     * a user identity.
     *
     * This credential uses the [Authorization Code Flow](https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-auth-code-flow).
     * On Node.js, it will open a browser window while it listens for a redirect response from the authentication service.
     * On browsers, it authenticates via popups. The `loginStyle` optional parameter can be set to `redirect` to authenticate by redirecting the user to an Azure secure login page, which then will redirect the user back to the web application where the authentication started.
     *
     * Configure your AAD Application to authenticate using a Single Page Application redirect endpoint.
     * More information here: [link](https://docs.microsoft.com/en-us/azure/active-directory/develop/scenario-spa-app-registration#redirect-uri-msaljs-20-with-auth-code-flow).
     *
     * @param options - Options for configuring the client which makes the authentication request.
     */
    constructor(_options: SPACredentialOptions);
    /**
     * (Only available in browsers)
     * Authenticates with Azure Active Directory and returns an access token if successful.
     * If authentication fails, a {@link CredentialUnavailableError} will be thrown with the details of the failure.
     *
     * @param scopes - The list of scopes for which the token will have access.
     * @param options - The options used to configure any requests this
     *                TokenCredential implementation might make.
     */
    getToken(): Promise<AccessToken | null>;
    /**
     * (Only available in browsers)
     * Authenticates with Azure Active Directory and returns an access token if successful.
     * If authentication fails, a {@link CredentialUnavailableError} will be thrown with the details of the failure.
     *
     * If the token can't be retrieved silently, this method will require user interaction to retrieve the token.
     *
     * @param scopes - The list of scopes for which the token will have access.
     * @param options - The options used to configure any requests this
     *                  TokenCredential implementation might make.
     */
    authenticate(): Promise<AuthenticationRecord | undefined>;
    /**
     * Tries to authenticate and retrieves parameters from the URL hash
     */
    onPageLoad(): Promise<{
        code?: string;
        state?: string;
    }>;
}

/**
 * Defines the common options for the RedirectCredential class.
 */
export declare interface SPACredentialOptions extends InteractiveCredentialOptions, CredentialPersistenceOptions {
    /**
     * Gets the redirect URI of the application. This should be same as the value
     * in the application registration portal.  Defaults to `window.location.href`.
     */
    redirectUri?: string | (() => string);
    /**
     * The Azure Active Directory tenant (directory) ID.
     */
    tenantId?: string;
    /**
     * The client (application) ID of an App Registration in the tenant.
     */
    clientId?: string;
    /**
     * loginHint allows a user name to be pre-selected for interactive logins.
     * Setting this option skips the account selection prompt and immediately attempts to login with the specified account.
     */
    loginHint?: string;
}

export { }
