var tslib_1 = require("tslib");
var keyvault_secrets_1 = require("@azure/keyvault-secrets");
var identity_1 = require("@azure/identity");
function main() {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var credential, url, client;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    credential = new identity_1.DefaultAzureCredential();
                    url = "https://" + process.env.KEY_VAULT_NAME + ".vault.azure.net";
                    client = new keyvault_secrets_1.SecretClient(url, credential);
                    return [4 /*yield*/, client.setSecret("secret-name", "secret-value")];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}

main().catch(function (err) {
    console.log("error code: ", err.code);
    console.log("error message: ", err.message);
    console.log("error stack: ", err.stack);
});
