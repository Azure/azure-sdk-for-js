let nock = require('nock');

module.exports.hash = "1f8d0464882356949ec20fb9901bed1a";

module.exports.testInfo = {"uniqueName":{"":"158700300978708132"},"newDate":{}}
