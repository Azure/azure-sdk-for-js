let nock = require('nock');

module.exports.hash = "79146c6240cfa8030bc2371c5048d2f7";

module.exports.testInfo = {"uniqueName":{"setConfigTestNA":"setConfigTestNA158696685579202551"},"newDate":{}}
