let nock = require('nock');

module.exports.hash = "35a74fd449126e45b315b3ab1ec53864";

module.exports.testInfo = {"uniqueName":{"addConfigTestTwice":"addConfigTestTwice158696680824002773"},"newDate":{}}
