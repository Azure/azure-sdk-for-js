import * as base from "./rollup.base.config";

const inputs = [];

inputs.push(base.nodeConfig());

export default inputs;
